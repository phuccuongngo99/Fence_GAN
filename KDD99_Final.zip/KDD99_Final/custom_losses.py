#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug  5 10:38:45 2018

@author: root
"""
import configparser
import json
import sys
import tensorflow as tf
from keras import losses
import keras.backend as K

loss_dict = {'dispersion_loss':[],'binary_loss':[]}

def tf_print(op, tensors, message=None):
    def print_message(x):
        #sys.stdout.write(message + " %s\n" % x)
        loss_dict[message].append(float(x))
        with open('loss.json','w+') as file:
            json.dump(loss_dict, file, indent=4)
        return x

    prints = [tf.py_func(print_message, [tensor], tensor.dtype) for tensor in tensors]
    with tf.control_dependencies(prints):
        op = tf.identity(op)
    return op

### Average distance from the Center of Mass
def com(G_out, weight, round_up):
    def dispersion_loss(y_true, y_pred):
        loss_b = tf.reduce_mean(losses.binary_crossentropy(y_true, y_pred))
        
        center = tf.reduce_mean(G_out, axis=0, keepdims=True)
        distance_xy = tf.square(tf.subtract(G_out,center))
        distance = tf.reduce_sum(distance_xy, 1)
        avg_distance = tf.reduce_mean(tf.sqrt(distance))
        loss_d = tf.reciprocal(avg_distance)
        
        loss_b = tf_print(loss_b, [loss_b], "binary_loss")
        loss_d = tf_print(loss_d, [loss_d], "dispersion_loss")
        
        loss = loss_b + weight*loss_d
        return loss
    return dispersion_loss

### Average electric force 1/r^2 between any pair
def electric(G_out, weight, round_up):
    def dispersion_loss(y_true, y_pred):
        loss_b = tf.reduce_mean(losses.binary_crossentropy(y_true, y_pred))
        
        r = tf.reduce_sum(G_out*G_out, 1)
        # turn r into column vector
        r = tf.reshape(r, [-1, 1])
        D = r - 2*tf.matmul(G_out, tf.transpose(G_out)) + tf.transpose(r)
        D = tf.cast(D, dtype=tf.float32)
        #Round up to a certain extent
        D = tf.maximum(D,1e-4)
        D = D + 1e6*tf.identity(D)
        D = tf.sqrt(D)
        D = tf.maximum(D,round_up)
        electric_force = tf.reciprocal(tf.pow(D,2))
        loss_d = tf.reduce_mean(electric_force)
        
        #tensorflow
        loss_b = tf_print(loss_b, [loss_b], "binary_loss")
        loss_d = tf_print(loss_d, [loss_d], "dispersion_loss")
        
        loss = loss_b + weight*loss_d
        return loss
    return dispersion_loss

### Average Lennard-Jones potential between any pair
### I just used the 1/r^6 - 1/r^3
def neutral(G_out, weight, round_up):
    def dispersion_loss(y_true, y_pred):
        loss_b = tf.reduce_mean(losses.binary_crossentropy(y_true, y_pred))
        
        r = tf.reduce_sum(G_out*G_out, 1)
        # turn r into column vector
        r = tf.reshape(r, [-1, 1])
        D = r - 2*tf.matmul(G_out, tf.transpose(G_out)) + tf.transpose(r) 
        D = tf.cast(D, dtype=tf.float32)
        #Round up distance to certain extent, if not when distance tend to zero, loss to infinity
        D = tf.maximum(D,1e-4)
        D = D + 1e6*tf.identity(D)
        D = tf.sqrt(D)
        D = tf.maximum(D,round_up)
        len_jon = tf.reciprocal(tf.pow(D,6)) - tf.reciprocal(tf.pow(D,3))
        loss_d = tf.reduce_mean(len_jon)
        
        #tensorflow
        loss_b = tf_print(loss_b, [loss_b], "binary_loss")
        loss_d = tf_print(loss_d, [loss_d], "dispersion_loss")
        
        loss = loss_b + weight*loss_d
        return loss
    
def minimax(G_out, weight, mini):
    def dispersion_loss(y_true, y_pred):
        loss_b = tf.reduce_mean(losses.binary_crossentropy(y_true, y_pred))
        
        #G_out is the tensor of coordinates
        r = tf.reduce_sum(G_out * G_out, 1)
        
        r = tf.reshape(r, [-1, 1])
        distance = r - 2*tf.matmul(G_out, tf.transpose(G_out)) + tf.transpose(r)
        minix = tf.constant(mini, dtype = tf.float32)
        distance_to_maximize = tf.reduce_min(tf.maximum(distance, minix))
        error = tf.reciprocal(distance_to_maximize)
        loss_d = tf.reduce_min(error)
        
        loss_b = tf_print(loss_b, [loss_b], "binary_loss")
        loss_d = tf_print(loss_d, [loss_d], "dispersion_loss")
        
        loss = loss_b + weight*loss_d
        return loss
    return dispersion_loss

def bc(G_out, weight, mini):
    def dispersion_loss(y_true, y_pred):
        loss_b = tf.reduce_mean(losses.binary_crossentropy(y_true, y_pred))
        
        #G_out is the tensor of coordinates
        r = tf.reduce_sum(G_out * G_out, 1)
        
        r = tf.reshape(r, [-1, 1])
        distance = r - 2*tf.matmul(G_out, tf.transpose(G_out)) + tf.transpose(r)
        minix = tf.constant(mini, dtype = tf.float32)
        distance_to_maximize = tf.reduce_min(tf.maximum(distance, minix))
        error = tf.reciprocal(distance_to_maximize)
        loss_d = tf.reduce_min(error)
        
        loss_b = tf_print(loss_b, [loss_b], "binary_loss")
        loss_d = tf_print(loss_d, [loss_d], "dispersion_loss")
        
        loss = loss_b + weight*loss_d
        return loss
    return dispersion_loss

def minimax2(G_out, weight):
    def dispersion_loss(y_true, y_pred):
        na = tf.shape(G_out)[0]
        nas = G_out.get_shape().as_list()
        a = tf.reshape(G_out, [na, 1, -1])
        b = tf.reshape(G_out, [1, na, 1])
        a.set_shape([nas[0], 1, np.prod(nas[1:])])
        b.set_shape([1, nas[0], np.prod(nas[1:])])
        a = tf.tile(a, [1, nb, 1])
        b = tf.tile(b, [na, 1, 1])
        d = a-b
        distance = tf.reduce_sum(tf.square(d), axis = 2)
        
import numpy as np
'''
def calculate_squared_distances(a, b):
    returns the squared distances between all elements in a and in b as a matrix
    of shape #a * #b
'''
'''
    na = tf.shape(a)[0]
    nb = tf.shape(b)[0]
    nas, nbs = a.get_shape().as_list(), b.get_shape().as_list()
    a = tf.reshape(a, [na, 1, -1])
    b = tf.reshape(b, [1, nb, -1])
    a.set_shape([nas[0], 1, np.prod(nas[1:])])
    b.set_shape([1, nbs[0], np.prod(nbs[1:])])
    a = tf.tile(a, [1, nb, 1])
    b = tf.tile(b, [na, 1, 1])
    d = a-b
    return tf.reduce_sum(tf.square(d), axis=2)


def plummer_kernel(a, b, dimension, epsilon):
    r = calculate_squared_distances(a, b)
    r += epsilon*epsilon
    f1 = dimension-2
    return tf.pow(r, -f1 / 2)


def get_potentials(x, y, dimension, cur_epsilon):
    
    This is alsmost the same `calculate_potential`, but
        px, py = get_potentials(x, y)
    is faster than:
        px = calculate_potential(x, y, x)
        py = calculate_potential(x, y, y)
    because we calculate the cross terms only once.
   
    x_fixed = tf.stop_gradient(x)
    y_fixed = tf.stop_gradient(y)
    nx = tf.cast(tf.shape(x)[0], x.dtype)
    ny = tf.cast(tf.shape(y)[0], y.dtype)
    pk_xx = plummer_kernel(x_fixed, x, dimension, cur_epsilon)
    pk_yx = plummer_kernel(y, x, dimension, cur_epsilon)
    pk_yy = plummer_kernel(y_fixed, y, dimension, cur_epsilon)
    #pk_xx = tf.matrix_set_diag(pk_xx, tf.ones(shape=x.get_shape()[0], dtype=pk_xx.dtype))
    #pk_yy = tf.matrix_set_diag(pk_yy, tf.ones(shape=y.get_shape()[0], dtype=pk_yy.dtype))
    kxx = tf.reduce_sum(pk_xx, axis=0) / (nx)
    kyx = tf.reduce_sum(pk_yx, axis=0) / ny
    kxy = tf.reduce_sum(pk_yx, axis=1) / (nx)
    kyy = tf.reduce_sum(pk_yy, axis=0) / ny
    pot_x = kxx - kyx
    pot_y = kxy - kyy
    pot_x = tf.reshape(pot_x, [-1])
    pot_y = tf.reshape(pot_y, [-1])
    return pot_x, pot_y


def calculate_potential(x, y, a, dimension, epsilon):
    x = tf.stop_gradient(x)
    y = tf.stop_gradient(y)
    nx = tf.cast(tf.shape(x)[0], x.dtype)
    ny = tf.cast(tf.shape(y)[0], y.dtype)
    kxa = plummer_kernel(x, a, dimension, epsilon)
    kxa = tf.reduce_sum(kxa, axis=0) / nx
    kya = plummer_kernel(y, a, dimension, epsilon)
    kya = tf.reduce_sum(kya, axis=0) / ny
    p = kxa - kya
    p = tf.reshape(p, [-1])
    return p
'''